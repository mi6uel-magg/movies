import 'dart:async';

import 'index.dart';
import 'serializers.dart';
import 'package:built_value/built_value.dart';

part 'movies_record.g.dart';

abstract class MoviesRecord
    implements Built<MoviesRecord, MoviesRecordBuilder> {
  static Serializer<MoviesRecord> get serializer => _$moviesRecordSerializer;

  @nullable
  String get titulo;

  @nullable
  int get ano;

  @nullable
  String get director;

  @nullable
  String get genero;

  @nullable
  String get sipnosis;

  @nullable
  DateTime get creadoalas;

  @nullable
  String get imagen;

  @nullable
  @BuiltValueField(wireName: kDocumentReferenceField)
  DocumentReference get reference;

  static void _initializeBuilder(MoviesRecordBuilder builder) => builder
    ..titulo = ''
    ..ano = 0
    ..director = ''
    ..genero = ''
    ..sipnosis = ''
    ..imagen = '';

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('movies');

  static Stream<MoviesRecord> getDocument(DocumentReference ref) => ref
      .snapshots()
      .map((s) => serializers.deserializeWith(serializer, serializedData(s)));

  static Future<MoviesRecord> getDocumentOnce(DocumentReference ref) => ref
      .get()
      .then((s) => serializers.deserializeWith(serializer, serializedData(s)));

  MoviesRecord._();
  factory MoviesRecord([void Function(MoviesRecordBuilder) updates]) =
      _$MoviesRecord;

  static MoviesRecord getDocumentFromData(
          Map<String, dynamic> data, DocumentReference reference) =>
      serializers.deserializeWith(serializer,
          {...mapFromFirestore(data), kDocumentReferenceField: reference});
}

Map<String, dynamic> createMoviesRecordData({
  String titulo,
  int ano,
  String director,
  String genero,
  String sipnosis,
  DateTime creadoalas,
  String imagen,
}) =>
    serializers.toFirestore(
        MoviesRecord.serializer,
        MoviesRecord((m) => m
          ..titulo = titulo
          ..ano = ano
          ..director = director
          ..genero = genero
          ..sipnosis = sipnosis
          ..creadoalas = creadoalas
          ..imagen = imagen));
