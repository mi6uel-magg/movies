// Export pages
export 'home_page/home_page_widget.dart' show HomePageWidget;
export 'pantalla_descripcion/pantalla_descripcion_widget.dart'
    show PantallaDescripcionWidget;
export 'pantalla_administracion/pantalla_administracion_widget.dart'
    show PantallaAdministracionWidget;
export 'pantalla_catalogo/pantalla_catalogo_widget.dart'
    show PantallaCatalogoWidget;
